import './App.css'
import { entries } from './data'
import { CardList } from './components/Cards'
import { useState } from 'react'

function App() {
  const [filteredText, setFilteredText] = useState("")
  function handleChange(e) {
    setFilteredText(e.target.value);
  }
  const filtered = entries.filter(entry => entry.title.toLowerCase().includes(filteredText.toLowerCase())
);

  return (
    <> 
      <h1>Mi blog de perros</h1>
      <div className = 'filter'>
        <p>Buscar:</p>
        <div className='search-box'>
          <span className='search-icon'>🔍</span>
          <input
            type='text'
            placeholder='Escribe una raza'
            value={filteredText}
            onChange={handleChange}
          />
          {filteredText && (
            <button className='clear-btn' onClick={() => setFilteredText("")}>✕</button>
          )}
        </div>
        {filteredText && (
          <p className='results-count'>{filtered.length} resultado(s)</p>
        )}
      </div>
      <CardList entries={filtered} filteredText={filteredText}></CardList>
    </>
  )
}


export default App