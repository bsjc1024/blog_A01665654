export function CardList({entries, filteredText}) {
    const cards = entries.map( entry => entry.title.includes(filteredText) && <Card id={entry.id} title = {entry.title} date = {entry.date} img = {entry.img}></Card>)
    return (
      <div className = 'card-list'>
        {cards}
      </div>
    )
}
  
export function Card({id, img, title, date}) {
    return (
      <div className = 'card' key = {id}>
        <img src ={img}></img>
        <h1>{title}</h1>
        <p>{date}</p>
      </div>
    )
}